# AcodePlugin
> Note: Official Acode plugin template returns many errors. This template is fully updated for termux.

> For typescript version of this template check out this: https://github.com/bajrangCoder/acode-plugin-template/tree/main-ts

For Detailed Documentation -> https://acode.foxdebug.com/plugin-docs

Official Template: https://github.com/deadlyjack/acode-plugin

## Use
Clone this repo
```
https://github.com/bajrangCoder/acode-plugin-template.git
```
Enter in the clonned repo
```
cd acode-plugin-template
```
Install node packages
```
npm install
```
For starting dev server
```
npm run start-dev
```

**Note:** Dev server works as a automatic webpack compiler
